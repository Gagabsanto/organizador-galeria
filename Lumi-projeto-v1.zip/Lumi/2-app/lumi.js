/* Lumi - interface (Fase 1: núcleo).
   Lê fotos e vídeos pelo plugin nativo LumiGaleria, organiza por pasta e por
   nome de arquivo (fatos, sem IA), mostra o visualizador e exclui com a
   confirmação do Android. Este arquivo não faz nenhuma chamada de rede. */
'use strict';
var items = [], lim = 600, tela = null, cur = null, selMode = false, lp = false;
var vlist = [], vi = 0, tx = 0, ty = 0, SDK = 0, info = {}, carregando = false;
var Galeria = (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.LumiGaleria) || null;
var io = null;

window.onerror = function (m) {
  var e = document.querySelector('#m');
  if (e) e.textContent = 'Erro no app: ' + m;
};
function $(s) { return document.querySelector(s); }
function el(t, c, x) {
  var e = document.createElement(t);
  if (c) e.className = c;
  if (x != null) e.textContent = x;
  return e;
}
function setm(t) { $('#m').textContent = t; }
function fonte(p) { return Capacitor.convertFileSrc(p); }
function fmt(ms) {
  var s = Math.round((ms || 0) / 1000), m = Math.floor(s / 60);
  s = s % 60;
  return m + ':' + (s < 10 ? '0' : '') + s;
}

/* ---------- endereços de cada arquivo (tenta o caminho, depois o content://) ---------- */
function cand(i) {
  var a = [];
  if (i.p) {
    a.push(fonte(encodeURI(i.p).replace(/#/g, '%23').replace(/\?/g, '%3F')));
    a.push(fonte(i.p));
  }
  if (i.u) a.push(fonte(i.u));
  return a;
}
function observa(m) {
  if (!window.IntersectionObserver) { m._go(); return; }
  if (!io) {
    io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.isIntersecting) { io.unobserve(e.target); e.target._go(); }
      });
    }, { rootMargin: '400px' });
  }
  io.observe(m);
}
/* Cria <img> ou <video>. Se nenhum endereço funcionar, marca i.bad e chama done. */
function midia(i, done) {
  var c = cand(i), k = 0, m;
  function falha() {
    k++;
    if (k < c.length) m.src = c[k] + (i.v ? '#t=0.1' : '');
    else { i.bad = true; m.onerror = null; if (done) done(); }
  }
  if (i.v) {
    m = document.createElement('video');
    m.muted = true; m.playsInline = true; m.preload = 'metadata'; m.onerror = falha;
    m._go = function () { if (c.length) m.src = c[0] + '#t=0.1'; else falha(); };
    observa(m);
  } else {
    m = document.createElement('img');
    m.alt = ''; m.loading = 'lazy'; m.onerror = falha;
    if (c.length) m.src = c[0]; else falha();
  }
  return m;
}
function capa(list, box, from, n) {
  while (from < list.length && list[from].bad) from++;
  if (from >= list.length || n > 6) { box.style.display = 'none'; return; }
  var m = midia(list[from], function () { box.innerHTML = ''; capa(list, box, from + 1, n + 1); });
  box.appendChild(m);
}

/* ---------- classificação por fatos (pasta, nome do arquivo, tamanho da tela) ---------- */
function ehPrint(w, h) {
  if (!tela || !w || !h) return false;
  var a = Math.max(w, h), b = Math.min(w, h), A = Math.max(tela.w, tela.h), B = Math.min(tela.w, tela.h);
  if (a === A && b === B) return true;
  return Math.abs(a / b - A / B) < 0.012 && a <= A * 1.02 && a >= A * 0.5;
}
function pasta(x) {
  var p = x.p || '', segs = (x.pasta || '').replace(/\\/g, '/').split('/').filter(Boolean);
  if (!segs.length) segs = p.split('/').slice(0, -1).filter(Boolean);
  var d = segs[segs.length - 1] || 'Outros';
  if (/^(sent|private)$/i.test(d)) d = (segs[segs.length - 2] || 'Outros') + ' · enviadas';
  return d;
}
var CONV = /whatsapp|telegram|messenger|signal|discord|mensagens|messages|sms|chat|conversa/i;
function album(x) {
  if (x.v) return 'Vídeos · ' + pasta(x);
  var p = x.p || '', f = x.nome || p.split('/').pop();
  if (/screenshot|captura/i.test(f) || /screenshots/i.test(p)) {
    var m = f.match(/screenshot[_ -]?\d{8}[-_ ]?\d{4,6}[_ -](.+)\.\w+$/i);
    var app = m ? m[1].replace(/[_-]+/g, ' ').trim() : '';
    if (CONV.test(app)) return 'Prints · Conversas';
    return app ? 'Prints · ' + app : 'Prints';
  }
  if (ehPrint(x.w, x.h)) return 'Prints recebidos';
  return pasta(x);
}
function groups() {
  var g = {};
  items.forEach(function (i) { if (i.bad) return; (g[i.a] = g[i.a] || []).push(i); });
  return g;
}

/* ---------- telas ---------- */
function logo() {
  var h = el('h1'); h.appendChild(document.createTextNode('Lu'));
  var b = el('b', 0, 'm'); h.appendChild(b); h.appendChild(document.createTextNode('i'));
  return h;
}
function boasVindas(msg) {
  cur = null; selMode = false;
  var hd = $('#hd'); hd.innerHTML = '';
  var app = $('#app'); app.innerHTML = '';
  var box = el('div', 'boas');
  box.appendChild(logo());
  box.appendChild(el('p', 0, msg || 'Para organizar suas fotos e vídeos, o Lumi precisa de permissão para ler a galeria. O Lumi só lê os arquivos no próprio celular.'));
  var b = el('button', 'pri', 'Permitir e ler a galeria');
  b.onclick = function () { ler(); };
  box.appendChild(b);
  app.appendChild(box);
}
function home() {
  cur = null; selMode = false;
  var g = groups(), ns = Object.keys(g).sort(function (a, b) {
    if (a === 'Prints · Conversas') return -1;
    if (b === 'Prints · Conversas') return 1;
    return g[b].length - g[a].length;
  });
  var total = 0; ns.forEach(function (n) { total += g[n].length; });
  var hd = $('#hd'); hd.innerHTML = '';
  hd.appendChild(logo());
  hd.appendChild(el('p', 'sub', total ? total + ' itens em ' + ns.length + ' álbuns' : 'Nenhuma foto ou vídeo encontrado'));
  var row = el('div', 'row');
  var b1 = el('button', 'pri', 'Atualizar'); b1.onclick = function () { ler(); };
  row.appendChild(b1); hd.appendChild(row);
  var app = $('#app'); app.innerHTML = '';
  var secs = [
    { t: 'Prints', f: function (n) { return n.indexOf('Prints') === 0; } },
    { t: 'Vídeos', f: function (n) { return n.indexOf('Vídeos · ') === 0; } },
    { t: 'Pastas do celular', f: function () { return true; } }];
  var used = {};
  secs.forEach(function (s) {
    var list = ns.filter(function (n) { return !used[n] && s.f(n); });
    if (!list.length) return;
    list.forEach(function (n) { used[n] = 1; });
    app.appendChild(el('div', 'sh', s.t));
    var grid = el('div', 'albums');
    list.forEach(function (n) {
      var isV = n.indexOf('Vídeos · ') === 0;
      var c = el('button', 'card'), box = el('div', 'cv'), t = el('div', 't');
      var fotos = g[n].filter(function (i) { return !i.v; });
      capa(fotos.length ? fotos : g[n], box, 0, 0);
      t.appendChild(el('b', 0, n.replace('Vídeos · ', '')));
      t.appendChild(el('span', 0, g[n].length + (isV ? ' vídeos' : ' itens')));
      c.appendChild(box); c.appendChild(t);
      c.onclick = function () { lim = 600; abrir(n); };
      grid.appendChild(c);
    });
    app.appendChild(grid);
  });
}
function nsel(list) { var c = 0; list.forEach(function (i) { if (i.s) c++; }); return c; }
function pinta(i) { if (i.el) i.el.classList.toggle('on', !!i.s); }
function barra(n, list) {
  var hd = $('#hd'); hd.innerHTML = '';
  var bar = el('div', 'bar');
  if (!selMode) {
    var bk = el('button', 'back', '‹ Voltar'); bk.onclick = home;
    var bs = el('button', 'back', 'Selecionar'); bs.onclick = function () { selMode = true; barra(n, list); };
    bar.appendChild(bk); bar.appendChild(el('h2', 0, n + ' (' + list.length + ')')); bar.appendChild(bs);
  } else {
    var c = nsel(list), bc = el('button', 'back', 'Cancelar');
    bc.onclick = function () { list.forEach(function (i) { i.s = false; pinta(i); }); selMode = false; barra(n, list); };
    var bt = el('button', 'back', 'Tudo');
    bt.onclick = function () { list.forEach(function (i) { i.s = true; pinta(i); }); barra(n, list); };
    var bd = el('button', 'back dang', 'Excluir'); bd.disabled = !c;
    bd.onclick = function () { apagar(list.filter(function (i) { return i.s; })); };
    bar.appendChild(bc); bar.appendChild(el('h2', 0, c + ' selecionados')); bar.appendChild(bt); bar.appendChild(bd);
  }
  hd.appendChild(bar);
}
function celula(i, n, list, idx) {
  var c = el('div', 'cell');
  c.appendChild(midia(i, function () { c.style.display = 'none'; }));
  if (i.v) c.appendChild(el('span', 'dur', '▶ ' + fmt(i.dur)));
  i.el = c; pinta(i);
  var t;
  c.ontouchstart = function () {
    lp = false;
    t = setTimeout(function () { lp = true; selMode = true; i.s = true; pinta(i); barra(n, list); }, 450);
  };
  c.ontouchend = c.ontouchmove = c.ontouchcancel = function () { clearTimeout(t); };
  c.onclick = function () {
    if (lp) { lp = false; return; }
    if (selMode) { i.s = !i.s; pinta(i); barra(n, list); } else mostrar(list, idx);
  };
  return c;
}
function abrir(n, keep) {
  cur = n;
  var list = groups()[n] || [];
  if (!keep) { selMode = false; list.forEach(function (i) { i.s = false; }); }
  barra(n, list);
  var app = $('#app'); app.innerHTML = '';
  var grid = el('div', 'grid');
  list.slice(0, lim).forEach(function (i, idx) { grid.appendChild(celula(i, n, list, idx)); });
  app.appendChild(grid);
  if (list.length > lim) {
    var mb = el('button', 'mais', 'Mostrar mais');
    mb.onclick = function () { lim += 600; abrir(n, true); };
    app.appendChild(mb);
  }
  window.scrollTo(0, 0);
}

/* ---------- visualizador (deslize para trocar de foto/vídeo) ---------- */
function fechaV() {
  var vv = $('#vv');
  if (vv.pause) vv.pause();
  if (vv.removeAttribute) vv.removeAttribute('src');
  $('#vw').style.display = 'none';
  document.body.classList.remove('viewer-open');
}
function mostrar(list, idx) {
  vlist = list; vi = idx; showV();
  $('#vw').style.display = 'flex';
  document.body.classList.add('viewer-open');
}
function showV() {
  var i = vlist[vi], im = $('#vim'), vv = $('#vv'), c = cand(i), k = 0;
  if (vv.pause) vv.pause();
  if (i.v) {
    im.style.display = 'none'; vv.style.display = 'block';
    vv.onerror = function () { k++; if (k < c.length) vv.src = c[k]; };
    vv.src = c[0]; vv.controls = true;
    var pp = vv.play && vv.play();
    if (pp && pp.catch) pp.catch(function () {});
  } else {
    vv.style.display = 'none';
    if (vv.removeAttribute) vv.removeAttribute('src');
    im.style.display = 'block'; im.style.opacity = '0';
    im.onerror = function () { k++; if (k < c.length) im.src = c[k]; else im.style.opacity = '1'; };
    im.onload = function () { im.style.opacity = '1'; };
    im.src = c[0];
    var nx = vlist[vi + 1];
    if (nx && !nx.v) new Image().src = cand(nx)[0];
  }
  $('#vc').textContent = (vi + 1) + ' / ' + vlist.length;
}
function nav(d) {
  var k = vi + d;
  if (k < 0 || k >= vlist.length) return;
  vi = k; showV();
}
$('#vw').ontouchstart = function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; };
$('#vw').ontouchend = function (e) {
  var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
  var atual = vlist[vi];
  if (atual && atual.v && ty > window.innerHeight - 130) return; /* área dos controles do vídeo */
  if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.25) nav(dx < 0 ? 1 : -1);
};
$('#vx').onclick = fechaV;
$('#vd').onclick = async function () {
  var ok = await apagar([vlist[vi]]);
  if (ok) {
    vlist.splice(vi, 1);
    if (!vlist.length) { fechaV(); home(); }
    else { if (vi >= vlist.length) vi = vlist.length - 1; showV(); }
  }
};

/* ---------- exclusão (confirmação do próprio Android) ---------- */
async function apagar(arr) {
  if (!arr.length) return false;
  if (!Galeria) { setm('O módulo da galeria não está disponível.'); return false; }
  if (arr.length > 2000) { setm('Selecione no máximo 2000 itens por vez.'); return false; }
  if (!confirm('Mover ' + arr.length + ' item(ns) para a lixeira do Android?')) return false;
  setm('Aguardando a confirmação do Android…');
  try {
    var r = await Galeria.apagar({ uris: arr.map(function (i) { return i.u; }), permanente: false });
    if (r.cancelado) { setm('Exclusão cancelada.'); return false; }
    setm(r.ok + ' item(ns) enviado(s) para a lixeira.');
    var rm = {}; arr.forEach(function (i) { rm[i.u] = 1; });
    items = items.filter(function (i) { return !rm[i.u]; });
    selMode = false;
    if (cur && groups()[cur]) abrir(cur); else home();
    return r.ok > 0;
  } catch (e) {
    setm('Não foi possível excluir: ' + (e.message || e));
    return false;
  }
}

/* ---------- leitura da galeria ---------- */
async function diag() {
  var versao = $('#dx').getAttribute('data-versao') || '';
  if (!Galeria) { $('#dx').textContent = 'Lumi ' + versao + ' · módulo nativo não encontrado'; return; }
  try {
    var r = await Galeria.estado(); SDK = r.sdk;
    var n = info.im != null ? ' · ' + info.im + ' fotos + ' + info.vd + ' vídeos' + (info.oc ? ' (' + info.oc + ' da lixeira ignorados)' : '') : '';
    $('#dx').textContent = 'Lumi ' + versao + ' · Android API ' + r.sdk + ' · permissão: ' + r.permissao + n;
  } catch (e) {
    $('#dx').textContent = 'Lumi ' + versao + ' · diagnóstico indisponível: ' + (e.message || e);
  }
}
async function ler(voltar, quieto) {
  if (!Galeria) { setm('O módulo da galeria não foi carregado no app.'); return; }
  if (carregando) return;
  carregando = true;
  if (!quieto) setm('Lendo todas as fotos e vídeos…');
  try {
    var r = await Galeria.listar();
    tela = { w: r.telaW, h: r.telaH };
    info = { im: r.imagens, vd: r.videos, oc: r.ocultas };
    items = r.fotos.map(function (x) {
      return { p: x.path, u: x.uri, w: x.w, h: x.h, v: !!x.v, dur: x.dur || 0, t: x.data || 0, nome: x.nome, pasta: x.pasta };
    });
    items.sort(function (a, b) { return b.t - a.t; });
    items.forEach(function (o) { o.a = album(o); });
    setm(items.length ? '' : 'Nenhuma foto ou vídeo encontrado.');
    if (voltar && groups()[voltar]) abrir(voltar); else home();
  } catch (e) {
    setm('Não foi possível ler: ' + (e.message || e));
    if (!items.length) boasVindas('Não consegui acessar a galeria. Confira a permissão de fotos e vídeos do Lumi e tente de novo.');
  }
  carregando = false;
  diag();
}
async function iniciar() {
  if (!Galeria) { boasVindas('O módulo nativo do Lumi não foi encontrado neste aparelho.'); diag(); return; }
  try {
    var r = await Galeria.estado();
    if (r.permissao === 'granted') { ler(); return; }
  } catch (e) { /* segue para a tela de boas-vindas */ }
  boasVindas();
  diag();
}
iniciar();
