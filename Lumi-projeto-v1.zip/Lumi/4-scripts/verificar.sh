#!/usr/bin/env bash
# Lumi - verificações. Uso: bash scripts/verificar.sh antes | depois
set -uo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
ERROS=0
erro() { echo "::error::$1"; ERROS=$((ERROS+1)); }
ok() { echo "OK  $1"; }
existe() { if [ -f "$1" ]; then ok "existe $1"; else erro "Arquivo ausente: $1 (suba este arquivo para a pasta certa do GitHub)"; fi; }

ESPERADO_ID="com.gagabsanto.lumi"

antes() {
  echo "=== Verificação ANTES de montar o projeto Android ==="
  for f in package.json capacitor.config.json version.properties \
           app/index.html app/lumi.css app/lumi.js \
           nativo/MainActivity.java nativo/LumiGaleriaPlugin.java nativo/ConfirmMediaActivity.java \
           nativo/ic_lumi_fg.xml nativo/ic_lumi_bg.xml \
           scripts/preparar-android.sh scripts/verificar.sh scripts/conferir-apk.sh; do
    existe "$f"
  done
  [ "$ERROS" -eq 0 ] || return

  node --check app/lumi.js && ok "app/lumi.js: sintaxe válida" || erro "app/lumi.js tem erro de sintaxe"
  for s in scripts/*.sh; do bash -n "$s" && ok "$s: sintaxe válida" || erro "$s tem erro de sintaxe"; done
  node -e "JSON.parse(require('fs').readFileSync('package.json','utf8'));JSON.parse(require('fs').readFileSync('capacitor.config.json','utf8'))" \
    && ok "package.json e capacitor.config.json são JSON válidos" || erro "package.json ou capacitor.config.json inválido"

  ID="$(node -p "require('./capacitor.config.json').appId" 2>/dev/null || true)"
  [ "$ID" = "$ESPERADO_ID" ] && ok "appId = $ID" || erro "capacitor.config.json: appId deveria ser $ESPERADO_ID (está: '$ID')"

  VC="$(grep -E '^versionCode=' version.properties | cut -d= -f2 | tr -d '[:space:]')"
  VN="$(grep -E '^versionName=' version.properties | cut -d= -f2 | tr -d '[:space:]')"
  [[ "$VC" =~ ^[0-9]+$ ]] && [ "${VC:-0}" -ge 1 ] && ok "versionCode = $VC" || erro "version.properties: versionCode inválido ('$VC')"
  [[ "$VN" =~ ^[0-9]+(\.[0-9]+){1,2}$ ]] && ok "versionName = $VN" || erro "version.properties: versionName inválido ('$VN')"

  for v in @capacitor/core @capacitor/android @capacitor/cli; do
    X="$(node -p "const p=require('./package.json');(p.dependencies&&p.dependencies['$v'])||(p.devDependencies&&p.devDependencies['$v'])||''")"
    [[ "$X" =~ ^7\.[0-9]+\.[0-9]+$ ]] && ok "$v fixado em $X" || erro "package.json: $v deve estar fixado em uma versão 7.x.y exata (está: '$X')"
  done

  for j in nativo/*.java; do
    grep -q "^package $ESPERADO_ID;" "$j" && ok "$j: pacote correto" || erro "$j: a linha 'package $ESPERADO_ID;' não foi encontrada"
  done
  python3 - <<'PY' && ok "ícones XML bem formados" || erro "XML do ícone inválido"
import xml.dom.minidom as m
for f in ("nativo/ic_lumi_fg.xml", "nativo/ic_lumi_bg.xml"):
    m.parse(f)
PY
  grep -q "__LUMI_VERSAO__" app/index.html && ok "marcador de versão presente em app/index.html" || erro "app/index.html perdeu o marcador __LUMI_VERSAO__"
  if grep -nE "fetch\(|XMLHttpRequest|WebSocket|https?://" app/lumi.js app/index.html app/lumi.css; then
    erro "Foi encontrada chamada de rede ou URL externa no app (o Lumi não deve usar internet nesta fase)"
  else
    ok "app sem chamadas de rede nem URLs externas"
  fi
}

depois() {
  echo "=== Verificação DEPOIS de montar o projeto Android ==="
  P="android/app/src/main/java/com/gagabsanto/lumi"
  for f in "$P/MainActivity.java" "$P/LumiGaleriaPlugin.java" "$P/ConfirmMediaActivity.java" \
           android/app/src/main/res/drawable/ic_lumi_fg.xml android/app/src/main/res/values/ic_lumi_bg.xml \
           android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml \
           android/app/src/main/AndroidManifest.xml android/app/build.gradle \
           android/app/src/main/assets/public/index.html android/app/src/main/assets/public/lumi.js android/app/src/main/assets/public/lumi.css; do
    existe "$f"
  done
  [ "$ERROS" -eq 0 ] || return

  MAN=android/app/src/main/AndroidManifest.xml
  python3 -c "import xml.dom.minidom as m;m.parse('$MAN')" && ok "AndroidManifest.xml bem formado" || erro "AndroidManifest.xml ficou inválido"
  for p in READ_MEDIA_IMAGES READ_MEDIA_VIDEO READ_EXTERNAL_STORAGE; do
    grep -q "android.permission.$p" "$MAN" && ok "permissão $p" || erro "Permissão $p ausente no manifest"
  done
  grep -q 'android:name=".ConfirmMediaActivity"' "$MAN" && ok "ConfirmMediaActivity registrada" || erro "ConfirmMediaActivity não registrada no manifest"
  G=android/app/build.gradle
  grep -q "signingConfigs" "$G" && grep -q "signingConfig signingConfigs.lumi" "$G" && ok "assinatura Lumi configurada no build.gradle" || erro "bloco de assinatura ausente no build.gradle"
  grep -qE "versionCode [0-9]+" "$G" && ok "versionCode definido no build.gradle" || erro "versionCode não definido no build.gradle"
  grep -Eq "applicationId[[:space:]]*=?[[:space:]]*[\"']$ESPERADO_ID[\"']" "$G" && ok "applicationId = $ESPERADO_ID" || erro "applicationId no build.gradle não é $ESPERADO_ID"
  grep -q "__LUMI_VERSAO__" android/app/src/main/assets/public/index.html && erro "O marcador de versão não foi substituído no app" || ok "versão aplicada em index.html"
}

case "${1:-}" in
  antes) antes ;;
  depois) depois ;;
  *) echo "Uso: bash scripts/verificar.sh antes|depois"; exit 2 ;;
esac

if [ "$ERROS" -gt 0 ]; then
  echo "::error::Verificação '$1' falhou com $ERROS problema(s). Corrija os itens marcados acima."
  exit 1
fi
echo "Verificação '$1' concluída sem problemas."
