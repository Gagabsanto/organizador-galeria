#!/usr/bin/env bash
# Lumi - prepara o projeto Android gerado pelo Capacitor.
# Roda DEPOIS de "npx cap add android" e ANTES de "npx cap sync android".
set -euo pipefail

falha() { echo "::error::$1"; exit 1; }

RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"

[ -d android/app/src/main ] || falha "A pasta android/ não existe. O passo 'npx cap add android' falhou ou não rodou antes deste script."
[ -f www/index.html ] || falha "A pasta www/ não tem index.html. Copie a pasta app/ para www/ antes de rodar este script."

APP_ID="$(node -p "require('./capacitor.config.json').appId")"
PKG_DIR="android/app/src/main/java/$(echo "$APP_ID" | tr . /)"
RES="android/app/src/main/res"
MAN="android/app/src/main/AndroidManifest.xml"
GRADLE="android/app/build.gradle"

VC="$(grep -E '^versionCode=' version.properties | cut -d= -f2 | tr -d '[:space:]')"
VN="$(grep -E '^versionName=' version.properties | cut -d= -f2 | tr -d '[:space:]')"
[[ "$VC" =~ ^[0-9]+$ ]] || falha "version.properties: versionCode deve ser um número inteiro (está: '$VC')."
[ "$VC" -ge 1 ] || falha "version.properties: versionCode deve ser 1 ou maior."
[[ "$VN" =~ ^[0-9]+(\.[0-9]+){1,2}$ ]] || falha "version.properties: versionName deve ser como 1.0.0 (está: '$VN')."

[ -f "$MAN" ] || falha "AndroidManifest.xml não encontrado em $MAN."
[ -f "$GRADLE" ] || falha "build.gradle do app não encontrado em $GRADLE."

echo "== Código nativo Java =="
mkdir -p "$PKG_DIR"
for f in MainActivity.java LumiGaleriaPlugin.java ConfirmMediaActivity.java; do
  [ -f "nativo/$f" ] || falha "Arquivo ausente: nativo/$f"
  cp "nativo/$f" "$PKG_DIR/$f"
  echo "copiado: $PKG_DIR/$f"
done

echo "== Ícone e identidade =="
mkdir -p "$RES/drawable" "$RES/values" "$RES/mipmap-anydpi-v26"
[ -f nativo/ic_lumi_fg.xml ] || falha "Arquivo ausente: nativo/ic_lumi_fg.xml"
[ -f nativo/ic_lumi_bg.xml ] || falha "Arquivo ausente: nativo/ic_lumi_bg.xml"
cp nativo/ic_lumi_fg.xml "$RES/drawable/ic_lumi_fg.xml"
cp nativo/ic_lumi_bg.xml "$RES/values/ic_lumi_bg.xml"
for n in ic_launcher ic_launcher_round; do
  cat > "$RES/mipmap-anydpi-v26/$n.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_lumi_bg" />
    <foreground android:drawable="@drawable/ic_lumi_fg" />
</adaptive-icon>
XML
done

echo "== Permissões e tela de confirmação no AndroidManifest.xml =="
python3 - "$MAN" <<'PY'
import re, sys
caminho = sys.argv[1]
t = open(caminho, encoding="utf-8").read()
permissoes = [
    '<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />',
    '<uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />',
    '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
]
novas = [p for p in permissoes if p.split('"')[1] not in t]
if novas:
    bloco = "".join("\n    " + p for p in novas)
    t, n = re.subn(r"(<manifest[^>]*>)", lambda m: m.group(1) + bloco, t, count=1)
    if n != 1:
        sys.exit("::error::Não encontrei a tag <manifest> no AndroidManifest.xml")
if "ConfirmMediaActivity" not in t:
    atv = '    <activity android:name=".ConfirmMediaActivity" android:exported="false" android:theme="@android:style/Theme.Translucent.NoTitleBar" />\n    '
    if "</application>" not in t:
        sys.exit("::error::Não encontrei </application> no AndroidManifest.xml")
    t = t.replace("</application>", atv + "</application>", 1)
open(caminho, "w", encoding="utf-8").write(t)
print("manifest atualizado")
PY

echo "== Versão, assinatura e opções de compilação no build.gradle =="
if grep -q "Lumi (gerado por scripts/preparar-android.sh)" "$GRADLE"; then
  echo "build.gradle já foi preparado; nada a fazer."
else
cat >> "$GRADLE" <<GRADLE

// ---- Lumi (gerado por scripts/preparar-android.sh) ----
android {
    defaultConfig {
        versionCode $VC
        versionName "$VN"
    }
    signingConfigs {
        lumi {
            storeFile file(System.getenv('LUMI_KEYSTORE_PATH') ?: 'lumi-sem-chave.p12')
            storePassword System.getenv('LUMI_KEYSTORE_PASSWORD')
            keyAlias 'lumi'
            keyPassword System.getenv('LUMI_KEYSTORE_PASSWORD')
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.lumi
            minifyEnabled false
            debuggable false
        }
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
}
GRADLE
fi

echo "== Versão exibida no app =="
sed -i "s|__LUMI_VERSAO__|$VN ($VC)|g" www/index.html
echo "Lumi $VN (versionCode $VC), id $APP_ID"
echo "Preparação concluída."
