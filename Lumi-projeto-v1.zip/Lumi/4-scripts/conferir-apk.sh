#!/usr/bin/env bash
# Lumi - confere o APK compilado (pacote, versão e assinatura) e prepara o arquivo final.
set -euo pipefail
falha() { echo "::error::$1"; exit 1; }

RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
ESPERADO_ID="com.gagabsanto.lumi"
APK="android/app/build/outputs/apk/release/app-release.apk"

[ -f "$APK" ] || falha "O APK assinado não foi gerado em $APK. Veja o passo de compilação acima; se aparecer 'app-release-unsigned.apk', a chave de assinatura não foi aplicada."

SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK_DIR" ] || falha "ANDROID_HOME não está definido neste ambiente."
BT="$(ls -d "$SDK_DIR"/build-tools/* 2>/dev/null | sort -V | tail -1)"
[ -n "$BT" ] || falha "Não encontrei o build-tools do Android em $SDK_DIR."
[ -x "$BT/apksigner" ] || falha "apksigner não encontrado em $BT."
[ -x "$BT/aapt2" ] || falha "aapt2 não encontrado em $BT."

SAIDA_SIG="$("$BT/apksigner" verify --verbose --print-certs "$APK")" || falha "A assinatura do APK é inválida."
echo "$SAIDA_SIG"
CERT="$(echo "$SAIDA_SIG" | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | sed -n 1p)"
[ -n "$CERT" ] || falha "Não consegui ler a impressão digital (SHA-256) da assinatura."

# Atenção: nada de "| head -1" direto no aapt2 (com pipefail, o pipe fechado derruba o script sem mensagem).
SAIDA_BADGING="$("$BT/aapt2" dump badging "$APK")" || falha "O aapt2 não conseguiu ler o APK."
DADOS="$(printf '%s\n' "$SAIDA_BADGING" | sed -n 1p)"
echo "$DADOS"
# Cada campo é lido com seu próprio rótulo (a linha também traz platformBuildVersionName etc.).
PKG="$(echo "$DADOS" | grep -oE "^package: name='[^']*'" | cut -d"'" -f2 || true)"
VC="$(echo "$DADOS" | grep -oE " versionCode='[^']*'" | sed -n 1p | cut -d"'" -f2 || true)"
VN="$(echo "$DADOS" | grep -oE " versionName='[^']*'" | sed -n 1p | cut -d"'" -f2 || true)"
EVC="$(grep -E '^versionCode=' version.properties | cut -d= -f2 | tr -d '[:space:]')"
EVN="$(grep -E '^versionName=' version.properties | cut -d= -f2 | tr -d '[:space:]')"

[ "$PKG" = "$ESPERADO_ID" ] || falha "Pacote do APK é '$PKG', mas deveria ser '$ESPERADO_ID'."
[ "$VC" = "$EVC" ] || falha "versionCode do APK é '$VC', mas version.properties diz '$EVC'."
[ "$VN" = "$EVN" ] || falha "versionName do APK é '$VN', mas version.properties diz '$EVN'."

TAM="$(stat -c %s "$APK")"
TAM_MB="$(awk "BEGIN{printf \"%.1f\", $TAM/1048576}")"
NOME="Lumi-$VN-$VC"
mkdir -p dist
cp "$APK" "dist/$NOME.apk"

{
  echo "## Lumi $VN (versionCode $VC)"
  echo "- Pacote: \`$PKG\`"
  echo "- Tamanho do APK: **$TAM_MB MB**"
  echo "- Assinatura (SHA-256): \`$CERT\`"
  echo ""
  echo "Para atualizar por cima, a assinatura (SHA-256) acima precisa ser a mesma das versões anteriores, e o versionCode precisa ser maior."
} >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
echo "nome=$NOME" >> "${GITHUB_OUTPUT:-/dev/null}"
echo "APK conferido: $NOME.apk ($TAM_MB MB)"
