package com.gagabsanto.lumi;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;

/**
 * Tela invisível que abre a confirmação do Android para mover itens
 * para a lixeira (MediaStore.createTrashRequest) e devolve o resultado.
 */
public class ConfirmMediaActivity extends Activity {
  public static final String EXTRA_PENDING_INTENT = "pendingIntent";
  private static final int REQUEST = 7401;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    PendingIntent pending = getIntent().getParcelableExtra(EXTRA_PENDING_INTENT);
    if (pending == null) {
      setResult(RESULT_CANCELED);
      finish();
      return;
    }
    try {
      startIntentSenderForResult(pending.getIntentSender(), REQUEST, null, 0, 0, 0);
    } catch (Exception e) {
      setResult(RESULT_CANCELED);
      finish();
    }
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQUEST) {
      setResult(resultCode, data);
      finish();
    }
  }
}
