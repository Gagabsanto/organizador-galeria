package com.gagabsanto.lumi;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import androidx.activity.result.ActivityResult;

import java.util.ArrayList;

/**
 * Plugin nativo do Lumi (Fase 1): lista fotos e vídeos e exclui com a
 * confirmação do sistema. Não usa rede e não grava nada fora do aparelho.
 */
@CapacitorPlugin(name = "LumiGaleria", permissions = {
  @Permission(alias = "midia", strings = { Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO }),
  @Permission(alias = "midiaAntigo", strings = { Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE })
})
public class LumiGaleriaPlugin extends Plugin {

  private String alias() {
    return Build.VERSION.SDK_INT >= 33 ? "midia" : "midiaAntigo";
  }

  @PluginMethod
  public void estado(PluginCall call) {
    JSObject r = new JSObject();
    r.put("sdk", Build.VERSION.SDK_INT);
    r.put("permissao", getPermissionState(alias()).toString());
    call.resolve(r);
  }

  @PluginMethod
  public void listar(PluginCall call) {
    if (getPermissionState(alias()) != PermissionState.GRANTED) {
      requestPermissionForAlias(alias(), call, "depoisPermissao");
      return;
    }
    ler(call);
  }

  @PermissionCallback
  private void depoisPermissao(PluginCall call) {
    if (getPermissionState(alias()) == PermissionState.GRANTED) {
      ler(call);
    } else {
      call.reject("Permissão negada. Em Configurações > Apps > Lumi > Permissões, permita o acesso a Fotos e vídeos.");
    }
  }

  private Uri baseUri(boolean video) {
    if (Build.VERSION.SDK_INT >= 29) {
      return video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                   : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
    }
    return video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
  }

  private void ler(PluginCall call) {
    try {
      JSArray arr = new JSArray();
      int qImagens = 0;
      int qVideos = 0;
      int ocultas = 0;
      ContentResolver cr = getContext().getContentResolver();
      for (int tipo = 0; tipo < 2; tipo++) {
        boolean video = tipo == 1;
        ArrayList<String> cols = new ArrayList<String>();
        cols.add(MediaStore.MediaColumns._ID);
        cols.add(MediaStore.MediaColumns.DATA);
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME);
        cols.add(MediaStore.MediaColumns.WIDTH);
        cols.add(MediaStore.MediaColumns.HEIGHT);
        cols.add(MediaStore.MediaColumns.DATE_ADDED);
        if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.MediaColumns.RELATIVE_PATH);
        if (video) cols.add(MediaStore.Video.Media.DURATION);
        Uri base = baseUri(video);
        Cursor c = cr.query(base, cols.toArray(new String[0]), null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");
        if (c == null) continue;
        int ci = c.getColumnIndex(MediaStore.MediaColumns._ID);
        int cd = c.getColumnIndex(MediaStore.MediaColumns.DATA);
        int cn = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
        int cw = c.getColumnIndex(MediaStore.MediaColumns.WIDTH);
        int ch = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT);
        int ct = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED);
        int cp = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
        int cdu = video ? c.getColumnIndex(MediaStore.Video.Media.DURATION) : -1;
        while (c.moveToNext()) {
          String p = cd >= 0 ? c.getString(cd) : "";
          if (p == null) p = "";
          if (p.contains("/.trashed-") || p.contains("/.pending-") || p.contains("/.thumbnails/")) {
            ocultas++;
            continue;
          }
          String nome = cn >= 0 ? c.getString(cn) : "";
          String rel = cp >= 0 ? c.getString(cp) : "";
          JSObject o = new JSObject();
          o.put("path", p);
          o.put("nome", nome == null ? "" : nome);
          o.put("pasta", rel == null ? "" : rel);
          o.put("uri", ContentUris.withAppendedId(base, c.getLong(ci)).toString());
          o.put("w", cw >= 0 ? c.getInt(cw) : 0);
          o.put("h", ch >= 0 ? c.getInt(ch) : 0);
          o.put("data", ct >= 0 ? c.getLong(ct) : 0L);
          o.put("v", video);
          o.put("dur", cdu >= 0 ? c.getLong(cdu) : 0L);
          arr.put(o);
          if (video) qVideos++; else qImagens++;
        }
        c.close();
      }

      android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
      getActivity().getWindowManager().getDefaultDisplay().getRealMetrics(dm);
      JSObject res = new JSObject();
      res.put("fotos", arr);
      res.put("imagens", qImagens);
      res.put("videos", qVideos);
      res.put("ocultas", ocultas);
      res.put("telaW", dm.widthPixels);
      res.put("telaH", dm.heightPixels);
      call.resolve(res);
    } catch (Exception e) {
      call.reject("Erro ao ler a galeria: " + e.getMessage());
    }
  }

  @PluginMethod
  public void apagar(PluginCall call) {
    try {
      JSArray arr = call.getArray("uris");
      boolean permanente = Boolean.TRUE.equals(call.getBoolean("permanente", false));
      if (arr == null || arr.length() == 0) {
        call.reject("Nenhum item foi selecionado.");
        return;
      }
      if (arr.length() > 2000) {
        call.reject("O Android limita uma solicitação a 2000 itens por vez.");
        return;
      }

      ArrayList<Uri> uris = new ArrayList<Uri>();
      for (int i = 0; i < arr.length(); i++) uris.add(Uri.parse(arr.getString(i)));

      if (Build.VERSION.SDK_INT >= 30) {
        android.app.PendingIntent request = permanente
          ? MediaStore.createDeleteRequest(getContext().getContentResolver(), uris)
          : MediaStore.createTrashRequest(getContext().getContentResolver(), uris, true);
        android.content.Intent intent = new android.content.Intent(getContext(), ConfirmMediaActivity.class);
        intent.putExtra(ConfirmMediaActivity.EXTRA_PENDING_INTENT, request);
        startActivityForResult(call, intent, "apagarResultado");
      } else {
        if (getPermissionState(alias()) != PermissionState.GRANTED) {
          requestPermissionForAlias(alias(), call, "depoisPermissaoApagar");
          return;
        }
        int ok = 0;
        for (Uri u : uris) if (getContext().getContentResolver().delete(u, null, null) > 0) ok++;
        JSObject r = new JSObject();
        r.put("ok", ok);
        r.put("falha", uris.size() - ok);
        r.put("cancelado", false);
        call.resolve(r);
      }
    } catch (Exception e) {
      call.reject("Erro ao excluir: " + e.getMessage());
    }
  }

  @ActivityCallback
  private void apagarResultado(PluginCall call, ActivityResult result) {
    JSObject r = new JSObject();
    if (result.getResultCode() == android.app.Activity.RESULT_OK) {
      r.put("ok", call.getArray("uris").length());
      r.put("falha", 0);
      r.put("cancelado", false);
    } else {
      r.put("ok", 0);
      r.put("falha", 0);
      r.put("cancelado", true);
    }
    call.resolve(r);
  }

  @PermissionCallback
  private void depoisPermissaoApagar(PluginCall call) {
    if (getPermissionState(alias()) == PermissionState.GRANTED) apagar(call);
    else call.reject("Permissão de armazenamento negada.");
  }
}
