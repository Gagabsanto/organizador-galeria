package com.gagabsanto.lumi;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(LumiGaleriaPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
