# Lumi

Organizador de galeria para Android. Lê fotos e vídeos do celular, agrupa por pasta e por nome de arquivo
(prints por aplicativo, conversas, vídeos), mostra tudo num visualizador com deslize e exclui itens com a
confirmação do próprio Android.

- Pacote Android: `com.gagabsanto.lumi` (não muda nunca)
- Fase atual: **1 – núcleo** (sem inteligência artificial e sem uso de internet pelo código do app)
- Compilação: GitHub Actions, workflow único `.github/workflows/lumi-build.yml`

## Estrutura do repositório

| Caminho | O que é |
|---|---|
| `.github/workflows/lumi-build.yml` | Único workflow. Ações: `compilar` (APK assinado) e `criar-chave` (só na primeira vez). |
| `app/` | Interface (HTML, CSS, JavaScript). Copiada para `www/` na compilação. |
| `nativo/` | Código Java do Android e ícone. Copiado para o projeto Android gerado na compilação. |
| `scripts/` | `verificar.sh` (checagens), `preparar-android.sh` (aplica o código nativo, permissões, versão e assinatura), `conferir-apk.sh` (confere o APK final). |
| `version.properties` | `versionCode` e `versionName`. É o único arquivo que você mexe a cada versão. |
| `package.json`, `capacitor.config.json` | Capacitor 7.4.4 e identidade do app (id e nome). |

A pasta `android/` e o `www/` são **gerados** a cada compilação e não ficam no repositório.

## Como lançar uma atualização

1. Altere os arquivos que quiser (por exemplo, `app/lumi.js`).
2. Edite `version.properties`: aumente o `versionCode` em 1 (obrigatório, senão o Android recusa a atualização
   por cima) e ajuste o `versionName`.
3. Envie as alterações para o GitHub. A compilação roda sozinha (ou rode manualmente em Actions > Lumi - Compilar APK > Run workflow > `compilar`).
4. Baixe o APK em **Artifacts** da execução e instale por cima da versão anterior.

## Assinatura (leia com atenção)

- A chave de assinatura fica **somente** nos Secrets do repositório: `LUMI_KEYSTORE_B64` e `LUMI_KEYSTORE_PASSWORD`.
  Nunca coloque senha ou chave em arquivos do repositório.
- A chave é criada uma única vez pela ação `criar-chave`, e só funciona em repositório **privado**.
- Guarde uma cópia dos dois valores em um lugar seguro fora do GitHub. Sem a chave não dá para atualizar o Lumi por cima:
  seria preciso desinstalar e perder os dados do app.
- Cada compilação mostra no resumo da execução o SHA-256 da assinatura. Ele deve ser sempre o mesmo.

## Fases planejadas

1. Núcleo (esta versão): fotos e vídeos, visualizador, exclusão, assinatura e atualização por cima.
2. Etiquetas e análise em lote com modelo local.
3. Leitura de texto em imagens.
4. Rostos (exige cuidados de privacidade e verificação de licença do modelo).

Cada fase só entra depois de verificar dependências, licença para uso comercial, tamanho do APK e desempenho.
